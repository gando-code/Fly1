import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Exercise library
export const exercises = sqliteTable("exercises", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  category: text("category").notNull(), // "compound" | "isolation" | "mobility" | "rehab"
  muscleGroup: text("muscle_group").notNull(), // "chest" | "back" | "shoulders" | "legs" | "arms" | "core" | "full_body"
  equipment: text("equipment").notNull(), // "barbell" | "dumbbell" | "cable" | "machine" | "bodyweight" | "band"
  isSpineSafe: integer("is_spine_safe", { mode: "boolean" }).notNull().default(true),
  notes: text("notes"),
});

// Workout sessions
export const workouts = sqliteTable("workouts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  date: text("date").notNull(), // ISO date string
  name: text("name").notNull(), // e.g., "Push Day", "Upper Body"
  duration: integer("duration"), // minutes
  notes: text("notes"),
  preWorkoutPain: integer("pre_workout_pain"), // 0-10
  postWorkoutPain: integer("post_workout_pain"), // 0-10
  painLocation: text("pain_location"), // JSON string array
  energyLevel: integer("energy_level"), // 1-5
  overallRating: integer("overall_rating"), // 1-5
});

// Individual sets within a workout
export const workoutSets = sqliteTable("workout_sets", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  workoutId: integer("workout_id").notNull().references(() => workouts.id, { onDelete: "cascade" }),
  exerciseId: integer("exercise_id").notNull().references(() => exercises.id),
  setNumber: integer("set_number").notNull(),
  reps: integer("reps"),
  weight: real("weight"), // lbs
  rpe: real("rpe"), // rate of perceived exertion 1-10
  isWarmup: integer("is_warmup", { mode: "boolean" }).notNull().default(false),
  notes: text("notes"),
});

// Daily recovery log
export const recoveryLogs = sqliteTable("recovery_logs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  date: text("date").notNull().unique(),
  sleepHours: real("sleep_hours"),
  sleepQuality: integer("sleep_quality"), // 1-5
  soreness: integer("soreness"), // 1-5 (1=none, 5=extreme)
  sorenessAreas: text("soreness_areas"), // JSON string array
  stressLevel: integer("stress_level"), // 1-5
  hydration: integer("hydration"), // 1-5
  nutrition: integer("nutrition"), // 1-5
  backPainLevel: integer("back_pain_level"), // 0-10
  notes: text("notes"),
});

// Body metrics
export const bodyMetrics = sqliteTable("body_metrics", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  date: text("date").notNull(),
  bodyWeight: real("body_weight"), // lbs
  bodyFat: real("body_fat"), // percentage
  notes: text("notes"),
});

// Insert schemas
export const insertExerciseSchema = createInsertSchema(exercises).omit({ id: true });
export const insertWorkoutSchema = createInsertSchema(workouts).omit({ id: true });
export const insertWorkoutSetSchema = createInsertSchema(workoutSets).omit({ id: true });
export const insertRecoveryLogSchema = createInsertSchema(recoveryLogs).omit({ id: true });
export const insertBodyMetricSchema = createInsertSchema(bodyMetrics).omit({ id: true });

// Types
export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;
export type Workout = typeof workouts.$inferSelect;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;
export type WorkoutSet = typeof workoutSets.$inferSelect;
export type InsertWorkoutSet = z.infer<typeof insertWorkoutSetSchema>;
export type RecoveryLog = typeof recoveryLogs.$inferSelect;
export type InsertRecoveryLog = z.infer<typeof insertRecoveryLogSchema>;
export type BodyMetric = typeof bodyMetrics.$inferSelect;
export type InsertBodyMetric = z.infer<typeof insertBodyMetricSchema>;
