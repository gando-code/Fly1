import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertExerciseSchema, insertWorkoutSchema, insertWorkoutSetSchema, insertRecoveryLogSchema, insertBodyMetricSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // --- Exercises ---
  app.get("/api/exercises", async (_req, res) => {
    const data = await storage.getExercises();
    res.json(data);
  });

  app.get("/api/exercises/:id", async (req, res) => {
    const ex = await storage.getExercise(Number(req.params.id));
    if (!ex) return res.status(404).json({ error: "Exercise not found" });
    res.json(ex);
  });

  app.post("/api/exercises", async (req, res) => {
    const parsed = insertExerciseSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const ex = await storage.createExercise(parsed.data);
    res.status(201).json(ex);
  });

  app.patch("/api/exercises/:id", async (req, res) => {
    const ex = await storage.updateExercise(Number(req.params.id), req.body);
    if (!ex) return res.status(404).json({ error: "Exercise not found" });
    res.json(ex);
  });

  app.delete("/api/exercises/:id", async (req, res) => {
    await storage.deleteExercise(Number(req.params.id));
    res.status(204).send();
  });

  // --- Workouts ---
  app.get("/api/workouts", async (_req, res) => {
    const data = await storage.getWorkouts();
    res.json(data);
  });

  app.get("/api/workouts/:id", async (req, res) => {
    const w = await storage.getWorkout(Number(req.params.id));
    if (!w) return res.status(404).json({ error: "Workout not found" });
    res.json(w);
  });

  app.post("/api/workouts", async (req, res) => {
    const parsed = insertWorkoutSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const w = await storage.createWorkout(parsed.data);
    res.status(201).json(w);
  });

  app.patch("/api/workouts/:id", async (req, res) => {
    const w = await storage.updateWorkout(Number(req.params.id), req.body);
    if (!w) return res.status(404).json({ error: "Workout not found" });
    res.json(w);
  });

  app.delete("/api/workouts/:id", async (req, res) => {
    await storage.deleteWorkout(Number(req.params.id));
    res.status(204).send();
  });

  // --- Workout Sets ---
  app.get("/api/workouts/:workoutId/sets", async (req, res) => {
    const data = await storage.getWorkoutSets(Number(req.params.workoutId));
    res.json(data);
  });

  app.post("/api/sets", async (req, res) => {
    const parsed = insertWorkoutSetSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const s = await storage.createWorkoutSet(parsed.data);
    res.status(201).json(s);
  });

  app.patch("/api/sets/:id", async (req, res) => {
    const s = await storage.updateWorkoutSet(Number(req.params.id), req.body);
    if (!s) return res.status(404).json({ error: "Set not found" });
    res.json(s);
  });

  app.delete("/api/sets/:id", async (req, res) => {
    await storage.deleteWorkoutSet(Number(req.params.id));
    res.status(204).send();
  });

  // --- Recovery ---
  app.get("/api/recovery", async (_req, res) => {
    const data = await storage.getRecoveryLogs();
    res.json(data);
  });

  app.get("/api/recovery/:date", async (req, res) => {
    const log = await storage.getRecoveryLog(req.params.date);
    if (!log) return res.status(404).json({ error: "Recovery log not found" });
    res.json(log);
  });

  app.post("/api/recovery", async (req, res) => {
    const parsed = insertRecoveryLogSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const log = await storage.upsertRecoveryLog(parsed.data);
    res.json(log);
  });

  // --- Body Metrics ---
  app.get("/api/metrics", async (_req, res) => {
    const data = await storage.getBodyMetrics();
    res.json(data);
  });

  app.post("/api/metrics", async (req, res) => {
    const parsed = insertBodyMetricSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const m = await storage.createBodyMetric(parsed.data);
    res.status(201).json(m);
  });

  // --- Seed exercises ---
  app.post("/api/seed", async (_req, res) => {
    const existing = await storage.getExercises();
    if (existing.length > 0) return res.json({ message: "Already seeded" });

    const seedExercises = [
      // Compound - Chest
      { name: "Bench Press", category: "compound", muscleGroup: "chest", equipment: "barbell", isSpineSafe: true, notes: "Flat bench, arch back slightly" },
      { name: "Incline Dumbbell Press", category: "compound", muscleGroup: "chest", equipment: "dumbbell", isSpineSafe: true, notes: "30-45 degree incline" },
      { name: "Dips", category: "compound", muscleGroup: "chest", equipment: "bodyweight", isSpineSafe: true, notes: "Lean forward for chest emphasis" },
      // Compound - Back
      { name: "Barbell Row", category: "compound", muscleGroup: "back", equipment: "barbell", isSpineSafe: false, notes: "Caution with herniated discs — use chest-supported alternative" },
      { name: "Lat Pulldown", category: "compound", muscleGroup: "back", equipment: "cable", isSpineSafe: true, notes: "Spine-safe alternative to pull-ups" },
      { name: "Seated Cable Row", category: "compound", muscleGroup: "back", equipment: "cable", isSpineSafe: true, notes: "Keep back neutral, squeeze scapulae" },
      { name: "Chest-Supported Row", category: "compound", muscleGroup: "back", equipment: "dumbbell", isSpineSafe: true, notes: "Excellent for back pain management" },
      // Compound - Legs
      { name: "Squat", category: "compound", muscleGroup: "legs", equipment: "barbell", isSpineSafe: false, notes: "Monitor disc pressure — consider belt squat or leg press" },
      { name: "Leg Press", category: "compound", muscleGroup: "legs", equipment: "machine", isSpineSafe: true, notes: "Spine-safe leg compound — don't round lower back at bottom" },
      { name: "Romanian Deadlift", category: "compound", muscleGroup: "legs", equipment: "barbell", isSpineSafe: false, notes: "Keep spine neutral — reduce ROM if needed for disc health" },
      { name: "Bulgarian Split Squat", category: "compound", muscleGroup: "legs", equipment: "dumbbell", isSpineSafe: true, notes: "Minimal spinal load, great for hypertrophy" },
      // Compound - Shoulders
      { name: "Overhead Press", category: "compound", muscleGroup: "shoulders", equipment: "barbell", isSpineSafe: false, notes: "Avoid excessive lumbar extension — use seated with back support" },
      { name: "Seated Dumbbell Press", category: "compound", muscleGroup: "shoulders", equipment: "dumbbell", isSpineSafe: true, notes: "Back supported against pad" },
      // Isolation
      { name: "Lateral Raise", category: "isolation", muscleGroup: "shoulders", equipment: "dumbbell", isSpineSafe: true, notes: "Light weight, control the negative" },
      { name: "Cable Fly", category: "isolation", muscleGroup: "chest", equipment: "cable", isSpineSafe: true, notes: null },
      { name: "Bicep Curl", category: "isolation", muscleGroup: "arms", equipment: "dumbbell", isSpineSafe: true, notes: null },
      { name: "Tricep Pushdown", category: "isolation", muscleGroup: "arms", equipment: "cable", isSpineSafe: true, notes: null },
      { name: "Face Pull", category: "isolation", muscleGroup: "shoulders", equipment: "cable", isSpineSafe: true, notes: "Great for posture and shoulder health" },
      { name: "Leg Curl", category: "isolation", muscleGroup: "legs", equipment: "machine", isSpineSafe: true, notes: null },
      { name: "Leg Extension", category: "isolation", muscleGroup: "legs", equipment: "machine", isSpineSafe: true, notes: null },
      { name: "Calf Raise", category: "isolation", muscleGroup: "legs", equipment: "machine", isSpineSafe: true, notes: null },
      // Rehab / Mobility
      { name: "Cat-Cow Stretch", category: "rehab", muscleGroup: "core", equipment: "bodyweight", isSpineSafe: true, notes: "Spinal mobility warmup — 10 slow reps" },
      { name: "Bird Dog", category: "rehab", muscleGroup: "core", equipment: "bodyweight", isSpineSafe: true, notes: "McGill Big 3 — anti-extension core stability" },
      { name: "Dead Bug", category: "rehab", muscleGroup: "core", equipment: "bodyweight", isSpineSafe: true, notes: "Press lower back into floor throughout" },
      { name: "McGill Curl-Up", category: "rehab", muscleGroup: "core", equipment: "bodyweight", isSpineSafe: true, notes: "McGill Big 3 — minimal spinal flexion" },
      { name: "Side Plank", category: "rehab", muscleGroup: "core", equipment: "bodyweight", isSpineSafe: true, notes: "McGill Big 3 — lateral core stability" },
      { name: "Glute Bridge", category: "rehab", muscleGroup: "legs", equipment: "bodyweight", isSpineSafe: true, notes: "Glute activation, spine-neutral hip extension" },
      { name: "Band Pull-Apart", category: "mobility", muscleGroup: "shoulders", equipment: "band", isSpineSafe: true, notes: "Shoulder prehab and posture correction" },
    ];

    for (const ex of seedExercises) {
      await storage.createExercise(ex);
    }
    res.json({ message: `Seeded ${seedExercises.length} exercises` });
  });

  return httpServer;
}
