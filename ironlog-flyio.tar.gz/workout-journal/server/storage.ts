import {
  type Exercise, type InsertExercise,
  type Workout, type InsertWorkout,
  type WorkoutSet, type InsertWorkoutSet,
  type RecoveryLog, type InsertRecoveryLog,
  type BodyMetric, type InsertBodyMetric,
  exercises, workouts, workoutSets, recoveryLogs, bodyMetrics,
} from "@shared/schema";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, asc, and, gte, lte } from "drizzle-orm";

const dbPath = process.env.DATABASE_PATH || "data.db";
const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite);

export interface IStorage {
  // Exercises
  getExercises(): Promise<Exercise[]>;
  getExercise(id: number): Promise<Exercise | undefined>;
  createExercise(ex: InsertExercise): Promise<Exercise>;
  updateExercise(id: number, ex: Partial<InsertExercise>): Promise<Exercise | undefined>;
  deleteExercise(id: number): Promise<void>;

  // Workouts
  getWorkouts(): Promise<Workout[]>;
  getWorkout(id: number): Promise<Workout | undefined>;
  createWorkout(w: InsertWorkout): Promise<Workout>;
  updateWorkout(id: number, w: Partial<InsertWorkout>): Promise<Workout | undefined>;
  deleteWorkout(id: number): Promise<void>;

  // Workout Sets
  getWorkoutSets(workoutId: number): Promise<WorkoutSet[]>;
  createWorkoutSet(s: InsertWorkoutSet): Promise<WorkoutSet>;
  updateWorkoutSet(id: number, s: Partial<InsertWorkoutSet>): Promise<WorkoutSet | undefined>;
  deleteWorkoutSet(id: number): Promise<void>;

  // Recovery
  getRecoveryLogs(): Promise<RecoveryLog[]>;
  getRecoveryLog(date: string): Promise<RecoveryLog | undefined>;
  upsertRecoveryLog(log: InsertRecoveryLog): Promise<RecoveryLog>;

  // Body metrics
  getBodyMetrics(): Promise<BodyMetric[]>;
  createBodyMetric(m: InsertBodyMetric): Promise<BodyMetric>;
}

export class DatabaseStorage implements IStorage {
  // Exercises
  async getExercises(): Promise<Exercise[]> {
    return db.select().from(exercises).orderBy(asc(exercises.name)).all();
  }
  async getExercise(id: number): Promise<Exercise | undefined> {
    return db.select().from(exercises).where(eq(exercises.id, id)).get();
  }
  async createExercise(ex: InsertExercise): Promise<Exercise> {
    return db.insert(exercises).values(ex).returning().get();
  }
  async updateExercise(id: number, ex: Partial<InsertExercise>): Promise<Exercise | undefined> {
    return db.update(exercises).set(ex).where(eq(exercises.id, id)).returning().get();
  }
  async deleteExercise(id: number): Promise<void> {
    db.delete(exercises).where(eq(exercises.id, id)).run();
  }

  // Workouts
  async getWorkouts(): Promise<Workout[]> {
    return db.select().from(workouts).orderBy(desc(workouts.date)).all();
  }
  async getWorkout(id: number): Promise<Workout | undefined> {
    return db.select().from(workouts).where(eq(workouts.id, id)).get();
  }
  async createWorkout(w: InsertWorkout): Promise<Workout> {
    return db.insert(workouts).values(w).returning().get();
  }
  async updateWorkout(id: number, w: Partial<InsertWorkout>): Promise<Workout | undefined> {
    return db.update(workouts).set(w).where(eq(workouts.id, id)).returning().get();
  }
  async deleteWorkout(id: number): Promise<void> {
    db.delete(workoutSets).where(eq(workoutSets.workoutId, id)).run();
    db.delete(workouts).where(eq(workouts.id, id)).run();
  }

  // Workout Sets
  async getWorkoutSets(workoutId: number): Promise<WorkoutSet[]> {
    return db.select().from(workoutSets).where(eq(workoutSets.workoutId, workoutId)).orderBy(asc(workoutSets.setNumber)).all();
  }
  async createWorkoutSet(s: InsertWorkoutSet): Promise<WorkoutSet> {
    return db.insert(workoutSets).values(s).returning().get();
  }
  async updateWorkoutSet(id: number, s: Partial<InsertWorkoutSet>): Promise<WorkoutSet | undefined> {
    return db.update(workoutSets).set(s).where(eq(workoutSets.id, id)).returning().get();
  }
  async deleteWorkoutSet(id: number): Promise<void> {
    db.delete(workoutSets).where(eq(workoutSets.id, id)).run();
  }

  // Recovery
  async getRecoveryLogs(): Promise<RecoveryLog[]> {
    return db.select().from(recoveryLogs).orderBy(desc(recoveryLogs.date)).all();
  }
  async getRecoveryLog(date: string): Promise<RecoveryLog | undefined> {
    return db.select().from(recoveryLogs).where(eq(recoveryLogs.date, date)).get();
  }
  async upsertRecoveryLog(log: InsertRecoveryLog): Promise<RecoveryLog> {
    const existing = await this.getRecoveryLog(log.date);
    if (existing) {
      return db.update(recoveryLogs).set(log).where(eq(recoveryLogs.date, log.date)).returning().get()!;
    }
    return db.insert(recoveryLogs).values(log).returning().get();
  }

  // Body metrics
  async getBodyMetrics(): Promise<BodyMetric[]> {
    return db.select().from(bodyMetrics).orderBy(desc(bodyMetrics.date)).all();
  }
  async createBodyMetric(m: InsertBodyMetric): Promise<BodyMetric> {
    return db.insert(bodyMetrics).values(m).returning().get();
  }
}

export const storage = new DatabaseStorage();
