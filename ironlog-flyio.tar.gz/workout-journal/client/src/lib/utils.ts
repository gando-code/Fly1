import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr + "T12:00:00");
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function rpeColor(rpe: number | null | undefined): string {
  if (!rpe) return "text-muted-foreground";
  if (rpe <= 6) return "text-chart-2";
  if (rpe <= 8) return "text-chart-4";
  return "text-chart-5";
}

export function painColor(pain: number | null | undefined): string {
  if (!pain || pain === 0) return "text-chart-2";
  if (pain <= 3) return "text-chart-4";
  if (pain <= 6) return "text-chart-1";
  return "text-chart-5";
}
