import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";
import {
  LayoutDashboard,
  Dumbbell,
  Library,
  HeartPulse,
  Moon,
  Sun,
  BarChart3,
  Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/workout", icon: Dumbbell, label: "Log Workout" },
  { path: "/exercises", icon: Library, label: "Exercises" },
  { path: "/pain", icon: Activity, label: "Pain Tracker" },
  { path: "/recovery", icon: HeartPulse, label: "Recovery" },
  { path: "/analytics", icon: BarChart3, label: "Analytics" },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex flex-col items-center w-16 py-4 gap-1 border-r border-border bg-sidebar h-full shrink-0">
        {/* Logo */}
        <div className="mb-4 flex items-center justify-center">
          <svg
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            aria-label="IronLog"
            className="text-primary"
          >
            <rect x="4" y="12" width="6" height="8" rx="1.5" fill="currentColor" opacity="0.6" />
            <rect x="22" y="12" width="6" height="8" rx="1.5" fill="currentColor" opacity="0.6" />
            <rect x="9" y="14" width="14" height="4" rx="1" fill="currentColor" />
            <rect x="2" y="13" width="4" height="6" rx="1" fill="currentColor" />
            <rect x="26" y="13" width="4" height="6" rx="1" fill="currentColor" />
          </svg>
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-1 flex-1">
          {navItems.map((item) => {
            const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
            return (
              <Tooltip key={item.path}>
                <TooltipTrigger asChild>
                  <Link href={item.path}>
                    <button
                      data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                      className={cn(
                        "w-10 h-10 flex items-center justify-center rounded-lg transition-colors",
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground hover:bg-accent"
                      )}
                    >
                      <item.icon className="w-5 h-5" />
                    </button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="right" sideOffset={8}>
                  {item.label}
                </TooltipContent>
              </Tooltip>
            );
          })}
        </nav>

        {/* Theme toggle */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
              className="text-muted-foreground"
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right" sideOffset={8}>
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </TooltipContent>
        </Tooltip>
      </aside>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t border-border bg-sidebar/95 backdrop-blur-sm px-2 py-1.5 safe-bottom">
        {navItems.map((item) => {
          const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
          return (
            <Link key={item.path} href={item.path}>
              <button
                data-testid={`nav-mobile-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                className={cn(
                  "flex flex-col items-center gap-0.5 px-2 py-1 rounded-md transition-colors",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-[10px] font-medium leading-none">{item.label.split(" ")[0]}</span>
              </button>
            </Link>
          );
        })}
        <button
          onClick={toggleTheme}
          data-testid="button-theme-toggle-mobile"
          className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-md text-muted-foreground"
        >
          {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          <span className="text-[10px] font-medium leading-none">Theme</span>
        </button>
      </nav>
    </>
  );
}
