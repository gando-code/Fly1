import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KpiCardProps {
  label: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "flat";
  trendValue?: string;
  className?: string;
}

export function KpiCard({ label, value, subtitle, icon, trend, trendValue, className }: KpiCardProps) {
  return (
    <Card className={cn("p-4 flex flex-col gap-2", className)}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        {icon && <span className="text-muted-foreground">{icon}</span>}
      </div>
      <div className="flex items-end gap-2">
        <span className="text-xl font-bold tabular-nums">{value}</span>
        {trend && trendValue && (
          <span
            className={cn(
              "text-xs font-medium tabular-nums pb-0.5",
              trend === "up" && "text-chart-2",
              trend === "down" && "text-chart-5",
              trend === "flat" && "text-muted-foreground"
            )}
          >
            {trend === "up" ? "+" : trend === "down" ? "-" : ""}{trendValue}
          </span>
        )}
      </div>
      {subtitle && <span className="text-xs text-muted-foreground">{subtitle}</span>}
    </Card>
  );
}
