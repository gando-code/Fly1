import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, painColor, rpeColor, cn } from "@/lib/utils";
import { ArrowLeft, Trash2, AlertTriangle, Clock, Flame, Star } from "lucide-react";
import type { Workout, WorkoutSet, Exercise } from "@shared/schema";

export default function WorkoutDetail() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const workoutId = Number(params.id);

  const { data: workout, isLoading: wl } = useQuery<Workout>({
    queryKey: ["/api/workouts", workoutId],
    queryFn: async () => {
      const res = await apiRequest("GET", `./api/workouts/${workoutId}`);
      return res.json();
    },
  });

  const { data: sets } = useQuery<WorkoutSet[]>({
    queryKey: ["/api/workouts", workoutId, "sets"],
    queryFn: async () => {
      const res = await apiRequest("GET", `./api/workouts/${workoutId}/sets`);
      return res.json();
    },
    enabled: !!workout,
  });

  const { data: exercises } = useQuery<Exercise[]>({ queryKey: ["/api/exercises"] });

  const deleteWorkout = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `./api/workouts/${workoutId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      toast({ title: "Workout deleted" });
      navigate("/");
    },
  });

  if (wl) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!workout) {
    return (
      <div className="p-6">
        <p className="text-sm text-muted-foreground">Workout not found.</p>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-2">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
      </div>
    );
  }

  // Group sets by exercise
  const exerciseMap = new Map<number, Exercise>();
  for (const ex of exercises ?? []) exerciseMap.set(ex.id, ex);

  const grouped: { exercise: Exercise | null; sets: WorkoutSet[] }[] = [];
  const seen = new Set<number>();
  for (const s of sets ?? []) {
    if (!seen.has(s.exerciseId)) {
      seen.add(s.exerciseId);
      grouped.push({
        exercise: exerciseMap.get(s.exerciseId) ?? null,
        sets: (sets ?? []).filter((ss) => ss.exerciseId === s.exerciseId),
      });
    }
  }

  // Volume stats
  const totalSets = (sets ?? []).filter((s) => !s.isWarmup).length;
  const totalVolume = (sets ?? []).reduce((sum, s) => {
    if (s.isWarmup || !s.reps || !s.weight) return sum;
    return sum + s.reps * s.weight;
  }, 0);

  const painLocations: string[] = workout.painLocation ? JSON.parse(workout.painLocation) : [];

  return (
    <div className="p-6 max-w-4xl space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")} data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-xl font-bold" data-testid="text-workout-name">{workout.name}</h1>
            <p className="text-sm text-muted-foreground">{formatDate(workout.date)}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => deleteWorkout.mutate()}
          className="text-destructive"
          data-testid="button-delete-workout"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Quick stats */}
      <div className="flex flex-wrap gap-3">
        {workout.duration && (
          <Badge variant="secondary" className="gap-1">
            <Clock className="w-3 h-3" /> {workout.duration}min
          </Badge>
        )}
        <Badge variant="secondary" className="gap-1 tabular-nums">
          <Flame className="w-3 h-3" /> {totalSets} sets
        </Badge>
        {totalVolume > 0 && (
          <Badge variant="secondary" className="gap-1 tabular-nums">
            {Math.round(totalVolume).toLocaleString()} lbs volume
          </Badge>
        )}
        {workout.overallRating && (
          <Badge variant="secondary" className="gap-1">
            <Star className="w-3 h-3" /> {workout.overallRating}/5
          </Badge>
        )}
      </div>

      {/* Pain info */}
      {(workout.preWorkoutPain !== null || workout.postWorkoutPain !== null) && (
        <Card className="p-4 space-y-2">
          <h2 className="text-sm font-semibold">Pain Assessment</h2>
          <div className="flex items-center gap-6">
            {workout.preWorkoutPain !== null && (
              <div>
                <span className="text-xs text-muted-foreground">Pre-workout</span>
                <div className={cn("text-lg font-bold tabular-nums", painColor(workout.preWorkoutPain))}>
                  {workout.preWorkoutPain}/10
                </div>
              </div>
            )}
            {workout.postWorkoutPain !== null && (
              <div>
                <span className="text-xs text-muted-foreground">Post-workout</span>
                <div className={cn("text-lg font-bold tabular-nums", painColor(workout.postWorkoutPain))}>
                  {workout.postWorkoutPain}/10
                </div>
              </div>
            )}
            {workout.preWorkoutPain !== null && workout.postWorkoutPain !== null && (
              <div>
                <span className="text-xs text-muted-foreground">Delta</span>
                <div className={cn(
                  "text-lg font-bold tabular-nums",
                  (workout.postWorkoutPain - workout.preWorkoutPain) > 0 ? "text-chart-5" : "text-chart-2"
                )}>
                  {(workout.postWorkoutPain - workout.preWorkoutPain) > 0 ? "+" : ""}
                  {workout.postWorkoutPain - workout.preWorkoutPain}
                </div>
              </div>
            )}
          </div>
          {painLocations.length > 0 && (
            <div className="flex gap-1.5 pt-1">
              {painLocations.map((loc) => (
                <Badge key={loc} variant="secondary" className="text-xs">{loc}</Badge>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Exercises */}
      {grouped.map((g, i) => (
        <Card key={i} className="p-4 space-y-2">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">{g.exercise?.name ?? "Unknown Exercise"}</h3>
            {g.exercise && !g.exercise.isSpineSafe && (
              <AlertTriangle className="w-3.5 h-3.5 text-chart-5" />
            )}
          </div>
          <div className="rounded-lg border border-border overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50">
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground w-12">Set</th>
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground">Reps</th>
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground">Weight</th>
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground">RPE</th>
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground">Volume</th>
                </tr>
              </thead>
              <tbody>
                {g.sets.map((s, j) => (
                  <tr key={s.id} className="border-t border-border">
                    <td className="p-2 tabular-nums text-muted-foreground">
                      {s.isWarmup ? "W" : j + 1 - g.sets.filter((ss, si) => si < j && ss.isWarmup).length}
                    </td>
                    <td className="p-2 tabular-nums">{s.reps ?? "—"}</td>
                    <td className="p-2 tabular-nums">{s.weight ? `${s.weight} lbs` : "—"}</td>
                    <td className={cn("p-2 tabular-nums font-medium", rpeColor(s.rpe))}>
                      {s.rpe ?? "—"}
                    </td>
                    <td className="p-2 tabular-nums text-muted-foreground">
                      {s.reps && s.weight ? `${(s.reps * s.weight).toLocaleString()} lbs` : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      ))}

      {/* Notes */}
      {workout.notes && (
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-1">Notes</h2>
          <p className="text-sm text-muted-foreground">{workout.notes}</p>
        </Card>
      )}
    </div>
  );
}
