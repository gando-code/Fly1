import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { formatDate, todayISO, cn } from "@/lib/utils";
import { Save, Moon, Droplets, Apple, Brain, Activity } from "lucide-react";
import type { RecoveryLog, BodyMetric } from "@shared/schema";

const sorenessAreas = ["Chest", "Back", "Shoulders", "Arms", "Core", "Quads", "Hamstrings", "Glutes", "Calves"];

export default function Recovery() {
  const { toast } = useToast();
  const { data: logs } = useQuery<RecoveryLog[]>({ queryKey: ["/api/recovery"] });
  const { data: metrics } = useQuery<BodyMetric[]>({ queryKey: ["/api/metrics"] });

  const [date, setDate] = useState(todayISO());
  const [sleepHours, setSleepHours] = useState<number | "">(7);
  const [sleepQuality, setSleepQuality] = useState<number[]>([3]);
  const [soreness, setSoreness] = useState<number[]>([2]);
  const [selectedSoreness, setSelectedSoreness] = useState<string[]>([]);
  const [stressLevel, setStressLevel] = useState<number[]>([3]);
  const [hydration, setHydration] = useState<number[]>([3]);
  const [nutrition, setNutrition] = useState<number[]>([3]);
  const [backPain, setBackPain] = useState<number[]>([0]);
  const [notes, setNotes] = useState("");

  // Body metric fields
  const [bodyWeight, setBodyWeight] = useState<number | "">("");
  const [bodyFat, setBodyFat] = useState<number | "">("");

  const saveRecovery = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "./api/recovery", {
        date,
        sleepHours: sleepHours ? Number(sleepHours) : null,
        sleepQuality: sleepQuality[0],
        soreness: soreness[0],
        sorenessAreas: selectedSoreness.length > 0 ? JSON.stringify(selectedSoreness) : null,
        stressLevel: stressLevel[0],
        hydration: hydration[0],
        nutrition: nutrition[0],
        backPainLevel: backPain[0],
        notes: notes || null,
      });

      if (bodyWeight || bodyFat) {
        await apiRequest("POST", "./api/metrics", {
          date,
          bodyWeight: bodyWeight ? Number(bodyWeight) : null,
          bodyFat: bodyFat ? Number(bodyFat) : null,
          notes: null,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ title: "Recovery logged", description: `Data saved for ${formatDate(date)}` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save recovery data.", variant: "destructive" });
    },
  });

  const ratingLabels = ["", "Poor", "Fair", "Good", "Great", "Excellent"];
  const sorenessLabels = ["", "None", "Mild", "Moderate", "High", "Extreme"];

  // Compute readiness score from latest data
  const readinessScore = (() => {
    const sq = sleepQuality[0];
    const sr = 6 - soreness[0]; // invert
    const st = 6 - stressLevel[0]; // invert
    const hy = hydration[0];
    const nu = nutrition[0];
    const bp = 5 - Math.round(backPain[0] / 2); // scale 0-10 to inverted 1-5
    const avg = (sq + sr + st + hy + nu + bp) / 6;
    return Math.round(avg * 20); // 0-100
  })();

  const readinessColor = readinessScore >= 70 ? "text-chart-2" : readinessScore >= 40 ? "text-chart-4" : "text-chart-5";

  return (
    <div className="p-6 max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" data-testid="text-recovery-title">Recovery Log</h1>
          <p className="text-sm text-muted-foreground">Track daily recovery metrics for smarter training</p>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground uppercase tracking-wider">Readiness</div>
          <div className={cn("text-xl font-bold tabular-nums", readinessColor)}>
            {readinessScore}%
          </div>
        </div>
      </div>

      {/* Date */}
      <Card className="p-4">
        <div className="flex items-center gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="recovery-date">Date</Label>
            <Input
              id="recovery-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-44"
              data-testid="input-recovery-date"
            />
          </div>
        </div>
      </Card>

      {/* Sleep */}
      <Card className="p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Moon className="w-4 h-4 text-chart-3" />
          <h2 className="text-sm font-semibold">Sleep</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-1.5">
            <Label>Hours of sleep</Label>
            <Input
              type="number"
              value={sleepHours}
              onChange={(e) => setSleepHours(e.target.value ? Number(e.target.value) : "")}
              min={0}
              max={14}
              step={0.5}
              placeholder="7.5"
              data-testid="input-sleep-hours"
            />
          </div>
          <div className="space-y-2">
            <Label>Sleep quality: <span className="font-semibold">{ratingLabels[sleepQuality[0]]}</span></Label>
            <Slider value={sleepQuality} onValueChange={setSleepQuality} min={1} max={5} step={1} data-testid="slider-sleep-quality" />
          </div>
        </div>
      </Card>

      {/* Soreness */}
      <Card className="p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-chart-4" />
          <h2 className="text-sm font-semibold">Muscle Soreness</h2>
        </div>
        <div className="space-y-2">
          <Label>Overall soreness: <span className="font-semibold">{sorenessLabels[soreness[0]]}</span></Label>
          <Slider value={soreness} onValueChange={setSoreness} min={1} max={5} step={1} data-testid="slider-soreness" />
        </div>
        <div className="space-y-2">
          <Label>Sore areas</Label>
          <div className="flex flex-wrap gap-2">
            {sorenessAreas.map((area) => (
              <Badge
                key={area}
                variant={selectedSoreness.includes(area) ? "default" : "secondary"}
                className="cursor-pointer"
                onClick={() =>
                  setSelectedSoreness((prev) =>
                    prev.includes(area) ? prev.filter((a) => a !== area) : [...prev, area]
                  )
                }
                data-testid={`badge-soreness-${area.toLowerCase()}`}
              >
                {area}
              </Badge>
            ))}
          </div>
        </div>
      </Card>

      {/* Wellness */}
      <Card className="p-4 space-y-4">
        <h2 className="text-sm font-semibold">Wellness Markers</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-chart-3" />
              <Label>Stress: <span className="font-semibold">{ratingLabels[6 - stressLevel[0]]}</span></Label>
            </div>
            <Slider value={stressLevel} onValueChange={setStressLevel} min={1} max={5} step={1} data-testid="slider-stress" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Droplets className="w-4 h-4 text-chart-2" />
              <Label>Hydration: <span className="font-semibold">{ratingLabels[hydration[0]]}</span></Label>
            </div>
            <Slider value={hydration} onValueChange={setHydration} min={1} max={5} step={1} data-testid="slider-hydration" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Apple className="w-4 h-4 text-chart-2" />
              <Label>Nutrition: <span className="font-semibold">{ratingLabels[nutrition[0]]}</span></Label>
            </div>
            <Slider value={nutrition} onValueChange={setNutrition} min={1} max={5} step={1} data-testid="slider-nutrition" />
          </div>
        </div>
      </Card>

      {/* Back pain */}
      <Card className="p-4 space-y-4">
        <h2 className="text-sm font-semibold">Back Pain Level</h2>
        <div className="space-y-2">
          <Label>
            Pain: <span className={cn("font-bold tabular-nums", backPain[0] > 5 ? "text-chart-5" : backPain[0] > 3 ? "text-chart-4" : "text-chart-2")}>{backPain[0]}/10</span>
          </Label>
          <Slider value={backPain} onValueChange={setBackPain} min={0} max={10} step={1} data-testid="slider-back-pain" />
        </div>
      </Card>

      {/* Body metrics */}
      <Card className="p-4 space-y-4">
        <h2 className="text-sm font-semibold">Body Metrics (optional)</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>Body Weight (lbs)</Label>
            <Input
              type="number"
              value={bodyWeight}
              onChange={(e) => setBodyWeight(e.target.value ? Number(e.target.value) : "")}
              placeholder="185"
              data-testid="input-body-weight"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Body Fat %</Label>
            <Input
              type="number"
              value={bodyFat}
              onChange={(e) => setBodyFat(e.target.value ? Number(e.target.value) : "")}
              placeholder="18"
              data-testid="input-body-fat"
            />
          </div>
        </div>
      </Card>

      {/* Notes */}
      <Card className="p-4 space-y-2">
        <Label htmlFor="recovery-notes">Notes</Label>
        <Textarea
          id="recovery-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="How are you feeling? Any symptoms?"
          data-testid="textarea-recovery-notes"
        />
      </Card>

      <Button
        onClick={() => saveRecovery.mutate()}
        disabled={saveRecovery.isPending}
        className="w-full sm:w-auto"
        data-testid="button-save-recovery"
      >
        <Save className="w-4 h-4 mr-2" />
        {saveRecovery.isPending ? "Saving..." : "Save Recovery Log"}
      </Button>

      {/* Recent logs */}
      {(logs ?? []).length > 0 && (
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Recent Recovery Logs</h2>
          <div className="space-y-2">
            {(logs ?? []).slice(0, 7).map((log) => (
              <div key={log.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                <div>
                  <span className="text-sm font-medium">{formatDate(log.date)}</span>
                  {log.sleepHours && (
                    <span className="text-xs text-muted-foreground ml-2">{log.sleepHours}h sleep</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {log.backPainLevel !== null && (
                    <Badge variant="secondary" className="tabular-nums text-xs">
                      Pain {log.backPainLevel}/10
                    </Badge>
                  )}
                  {log.soreness !== null && (
                    <Badge variant="secondary" className="tabular-nums text-xs">
                      Sore {log.soreness}/5
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
