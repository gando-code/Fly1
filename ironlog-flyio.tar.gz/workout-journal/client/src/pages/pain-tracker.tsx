import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate, painColor, cn } from "@/lib/utils";
import { AlertTriangle, TrendingDown, TrendingUp, Minus } from "lucide-react";
import type { Workout, RecoveryLog } from "@shared/schema";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  CartesianGrid,
  Area,
  AreaChart,
  ReferenceLine,
} from "recharts";

export default function PainTracker() {
  const { data: workouts } = useQuery<Workout[]>({ queryKey: ["/api/workouts"] });
  const { data: recovery } = useQuery<RecoveryLog[]>({ queryKey: ["/api/recovery"] });

  // Build unified pain timeline from workouts + recovery
  const workoutPainData = (workouts ?? [])
    .filter((w) => w.preWorkoutPain !== null || w.postWorkoutPain !== null)
    .slice(0, 30)
    .reverse()
    .map((w) => ({
      date: formatDate(w.date),
      rawDate: w.date,
      pre: w.preWorkoutPain ?? 0,
      post: w.postWorkoutPain ?? 0,
      delta: (w.postWorkoutPain ?? 0) - (w.preWorkoutPain ?? 0),
      workout: w.name,
    }));

  const recoveryPainData = (recovery ?? [])
    .filter((r) => r.backPainLevel !== null)
    .slice(0, 30)
    .reverse()
    .map((r) => ({
      date: formatDate(r.date),
      pain: r.backPainLevel ?? 0,
      soreness: r.soreness ?? 0,
    }));

  // Pain by exercise type analysis
  const painByWorkoutType: Record<string, { count: number; avgDelta: number; avgPost: number }> = {};
  for (const w of workouts ?? []) {
    if (w.preWorkoutPain === null && w.postWorkoutPain === null) continue;
    const key = w.name;
    if (!painByWorkoutType[key]) painByWorkoutType[key] = { count: 0, avgDelta: 0, avgPost: 0 };
    painByWorkoutType[key].count++;
    painByWorkoutType[key].avgDelta += (w.postWorkoutPain ?? 0) - (w.preWorkoutPain ?? 0);
    painByWorkoutType[key].avgPost += w.postWorkoutPain ?? 0;
  }
  Object.values(painByWorkoutType).forEach((v) => {
    v.avgDelta = Math.round((v.avgDelta / v.count) * 10) / 10;
    v.avgPost = Math.round((v.avgPost / v.count) * 10) / 10;
  });

  // Pain location frequency from workouts
  const painLocationFreq: Record<string, number> = {};
  for (const w of workouts ?? []) {
    if (!w.painLocation) continue;
    try {
      const locs: string[] = JSON.parse(w.painLocation);
      for (const l of locs) {
        painLocationFreq[l] = (painLocationFreq[l] || 0) + 1;
      }
    } catch {}
  }

  // Latest stats
  const latestRecovery = (recovery ?? [])[0];
  const latestWorkout = (workouts ?? [])[0];
  const avgPain7d = (() => {
    const recent = (recovery ?? []).slice(0, 7).filter((r) => r.backPainLevel !== null);
    if (recent.length === 0) return null;
    return Math.round((recent.reduce((s, r) => s + (r.backPainLevel ?? 0), 0) / recent.length) * 10) / 10;
  })();

  return (
    <div className="p-6 max-w-5xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" data-testid="text-pain-tracker-title">Pain Tracker</h1>
        <p className="text-sm text-muted-foreground">
          Track back pain patterns to optimize training around your herniated discs
        </p>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Current Pain</span>
          <div className={cn("text-xl font-bold tabular-nums mt-1", painColor(latestRecovery?.backPainLevel))}>
            {latestRecovery?.backPainLevel ?? "—"}<span className="text-sm font-normal text-muted-foreground">/10</span>
          </div>
        </Card>
        <Card className="p-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">7-Day Average</span>
          <div className={cn("text-xl font-bold tabular-nums mt-1", painColor(avgPain7d))}>
            {avgPain7d ?? "—"}<span className="text-sm font-normal text-muted-foreground">/10</span>
          </div>
        </Card>
        <Card className="p-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Last Workout Impact</span>
          <div className="flex items-center gap-1 mt-1">
            {latestWorkout && latestWorkout.preWorkoutPain != null && latestWorkout.postWorkoutPain != null ? (
              <>
                <span className="text-xl font-bold tabular-nums">
                  {(latestWorkout.postWorkoutPain - latestWorkout.preWorkoutPain)}
                </span>
                {(latestWorkout.postWorkoutPain - latestWorkout.preWorkoutPain) > 0 ? (
                  <TrendingUp className="w-4 h-4 text-chart-5" />
                ) : (latestWorkout.postWorkoutPain - latestWorkout.preWorkoutPain) < 0 ? (
                  <TrendingDown className="w-4 h-4 text-chart-2" />
                ) : (
                  <Minus className="w-4 h-4 text-muted-foreground" />
                )}
              </>
            ) : (
              <span className="text-xl font-bold">—</span>
            )}
          </div>
        </Card>
        <Card className="p-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Top Pain Area</span>
          <div className="mt-1">
            {Object.keys(painLocationFreq).length > 0 ? (
              <span className="text-sm font-semibold">
                {Object.entries(painLocationFreq).sort((a, b) => b[1] - a[1])[0][0]}
              </span>
            ) : (
              <span className="text-xl font-bold">—</span>
            )}
          </div>
        </Card>
      </div>

      {/* Pain over time */}
      <Card className="p-4">
        <h2 className="text-sm font-semibold mb-3">Daily Back Pain Level</h2>
        {recoveryPainData.length > 0 ? (
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={recoveryPainData}>
              <defs>
                <linearGradient id="painGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-5))" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="hsl(var(--chart-5))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <RechartsTooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <ReferenceLine y={3} stroke="hsl(var(--chart-2))" strokeDasharray="3 3" label={{ value: "Manageable", fill: "hsl(var(--chart-2))", fontSize: 10 }} />
              <ReferenceLine y={7} stroke="hsl(var(--chart-5))" strokeDasharray="3 3" label={{ value: "Warning", fill: "hsl(var(--chart-5))", fontSize: 10 }} />
              <Area type="monotone" dataKey="pain" stroke="hsl(var(--chart-5))" fill="url(#painGrad)" strokeWidth={2} name="Back Pain" />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[220px] flex items-center justify-center text-sm text-muted-foreground">
            Log recovery data to track pain trends
          </div>
        )}
      </Card>

      {/* Workout impact */}
      <Card className="p-4">
        <h2 className="text-sm font-semibold mb-3">Pre vs Post Workout Pain</h2>
        {workoutPainData.length > 0 ? (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={workoutPainData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <RechartsTooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Line type="monotone" dataKey="pre" stroke="hsl(var(--chart-4))" strokeWidth={2} dot={{ r: 3 }} name="Pre-workout" />
              <Line type="monotone" dataKey="post" stroke="hsl(var(--chart-5))" strokeWidth={2} dot={{ r: 3 }} name="Post-workout" />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[220px] flex items-center justify-center text-sm text-muted-foreground">
            Log workouts with pain data to see impact analysis
          </div>
        )}
      </Card>

      {/* Pain by workout type */}
      {Object.keys(painByWorkoutType).length > 0 && (
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Pain Impact by Workout Type</h2>
          <div className="space-y-2">
            {Object.entries(painByWorkoutType)
              .sort((a, b) => a[1].avgDelta - b[1].avgDelta)
              .map(([name, data]) => (
                <div key={name} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                  <div>
                    <span className="text-sm font-medium">{name}</span>
                    <span className="text-xs text-muted-foreground ml-2">({data.count} sessions)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground">Avg post: {data.avgPost}/10</span>
                    <Badge variant={data.avgDelta > 0 ? "destructive" : "secondary"} className="tabular-nums">
                      {data.avgDelta > 0 ? "+" : ""}{data.avgDelta}
                    </Badge>
                  </div>
                </div>
              ))}
          </div>
        </Card>
      )}

      {/* Pain location heatmap */}
      {Object.keys(painLocationFreq).length > 0 && (
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Pain Location Frequency</h2>
          <div className="flex flex-wrap gap-2">
            {Object.entries(painLocationFreq)
              .sort((a, b) => b[1] - a[1])
              .map(([loc, count]) => (
                <Badge key={loc} variant="secondary" className="text-sm">
                  {loc}: {count}x
                </Badge>
              ))}
          </div>
        </Card>
      )}
    </div>
  );
}
