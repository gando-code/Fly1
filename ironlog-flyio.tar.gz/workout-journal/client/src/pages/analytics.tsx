import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { KpiCard } from "@/components/kpi-card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, cn } from "@/lib/utils";
import { Dumbbell, TrendingUp, Activity, Calendar } from "lucide-react";
import type { Workout, WorkoutSet, Exercise, RecoveryLog, BodyMetric } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  CartesianGrid,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

export default function Analytics() {
  const { data: workouts, isLoading: wl } = useQuery<Workout[]>({ queryKey: ["/api/workouts"] });
  const { data: exercises } = useQuery<Exercise[]>({ queryKey: ["/api/exercises"] });
  const { data: recovery } = useQuery<RecoveryLog[]>({ queryKey: ["/api/recovery"] });
  const { data: metrics } = useQuery<BodyMetric[]>({ queryKey: ["/api/metrics"] });

  if (wl) {
    return (
      <div className="p-6 space-y-6">
        {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-24 rounded-lg" />)}
      </div>
    );
  }

  const allWorkouts = workouts ?? [];
  const allRecovery = recovery ?? [];
  const allMetrics = metrics ?? [];

  // Total workouts
  const totalWorkouts = allWorkouts.length;

  // This month workouts
  const now = new Date();
  const thisMonth = allWorkouts.filter((w) => {
    const d = new Date(w.date + "T12:00:00");
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  // Average workout duration
  const avgDuration = (() => {
    const withDur = allWorkouts.filter((w) => w.duration);
    if (withDur.length === 0) return 0;
    return Math.round(withDur.reduce((s, w) => s + (w.duration ?? 0), 0) / withDur.length);
  })();

  // Consistency — workouts per week over last 4 weeks
  const weeksData = (() => {
    const weeks: { label: string; count: number }[] = [];
    for (let i = 3; i >= 0; i--) {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - (i + 1) * 7);
      const weekEnd = new Date();
      weekEnd.setDate(weekEnd.getDate() - i * 7);
      const count = allWorkouts.filter((w) => {
        const d = new Date(w.date + "T12:00:00");
        return d >= weekStart && d < weekEnd;
      }).length;
      weeks.push({
        label: `Wk ${4 - i}`,
        count,
      });
    }
    return weeks;
  })();

  // Muscle group distribution
  const muscleGroupData = (() => {
    const counts: Record<string, number> = {};
    for (const w of allWorkouts) {
      // Simple heuristic from workout name
      const name = w.name.toLowerCase();
      if (name.includes("push") || name.includes("chest")) counts["Chest"] = (counts["Chest"] || 0) + 1;
      else if (name.includes("pull") || name.includes("back")) counts["Back"] = (counts["Back"] || 0) + 1;
      else if (name.includes("leg") || name.includes("lower")) counts["Legs"] = (counts["Legs"] || 0) + 1;
      else if (name.includes("shoulder")) counts["Shoulders"] = (counts["Shoulders"] || 0) + 1;
      else if (name.includes("arm")) counts["Arms"] = (counts["Arms"] || 0) + 1;
      else if (name.includes("full") || name.includes("total")) counts["Full Body"] = (counts["Full Body"] || 0) + 1;
      else counts["Other"] = (counts["Other"] || 0) + 1;
    }
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  })();

  const pieColors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
    "hsl(var(--muted-foreground))",
  ];

  // Body weight trend
  const weightData = allMetrics
    .filter((m) => m.bodyWeight)
    .slice(0, 30)
    .reverse()
    .map((m) => ({
      date: formatDate(m.date),
      weight: m.bodyWeight,
    }));

  // Recovery score trend
  const recoveryScoreData = allRecovery
    .slice(0, 14)
    .reverse()
    .map((r) => {
      const sq = r.sleepQuality ?? 3;
      const sr = 6 - (r.soreness ?? 3);
      const st = 6 - (r.stressLevel ?? 3);
      const hy = r.hydration ?? 3;
      const nu = r.nutrition ?? 3;
      const bp = 5 - Math.round((r.backPainLevel ?? 0) / 2);
      const avg = (sq + sr + st + hy + nu + bp) / 6;
      return {
        date: formatDate(r.date),
        score: Math.round(avg * 20),
      };
    });

  // Average rating
  const avgRating = (() => {
    const rated = allWorkouts.filter((w) => w.overallRating);
    if (rated.length === 0) return 0;
    return Math.round((rated.reduce((s, w) => s + (w.overallRating ?? 0), 0) / rated.length) * 10) / 10;
  })();

  return (
    <div className="p-6 max-w-6xl space-y-6">
      <h1 className="text-xl font-bold" data-testid="text-analytics-title">Analytics</h1>

      {/* Top KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Total Workouts"
          value={totalWorkouts}
          icon={<Dumbbell className="w-4 h-4" />}
        />
        <KpiCard
          label="This Month"
          value={thisMonth.length}
          icon={<Calendar className="w-4 h-4" />}
        />
        <KpiCard
          label="Avg Duration"
          value={avgDuration ? `${avgDuration}min` : "—"}
          icon={<Activity className="w-4 h-4" />}
        />
        <KpiCard
          label="Avg Rating"
          value={avgRating ? `${avgRating}/5` : "—"}
          icon={<TrendingUp className="w-4 h-4" />}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Weekly consistency */}
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Weekly Consistency</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeksData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="label" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <RechartsTooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Workouts" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Muscle group distribution */}
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Training Split</h2>
          {muscleGroupData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={muscleGroupData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {muscleGroupData.map((_, i) => (
                    <Cell key={i} fill={pieColors[i % pieColors.length]} />
                  ))}
                </Pie>
                <Legend
                  verticalAlign="middle"
                  align="right"
                  layout="vertical"
                  formatter={(value) => <span className="text-xs">{value}</span>}
                />
                <RechartsTooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">
              Log workouts to see your training split
            </div>
          )}
        </Card>
      </div>

      {/* Body weight and recovery trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Body Weight Trend</h2>
          {weightData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={weightData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis domain={["auto", "auto"]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <RechartsTooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line type="monotone" dataKey="weight" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} name="Weight (lbs)" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">
              Log body weight in Recovery to track trends
            </div>
          )}
        </Card>

        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Readiness Score Trend</h2>
          {recoveryScoreData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={recoveryScoreData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <RechartsTooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line type="monotone" dataKey="score" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 3 }} name="Readiness %" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">
              Log recovery data to track readiness
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
