import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { Plus, Search, AlertTriangle, Shield } from "lucide-react";
import type { Exercise } from "@shared/schema";

const muscleGroups = ["chest", "back", "shoulders", "legs", "arms", "core", "full_body"];
const categories = ["compound", "isolation", "rehab", "mobility"];
const equipmentTypes = ["barbell", "dumbbell", "cable", "machine", "bodyweight", "band"];

export default function Exercises() {
  const { toast } = useToast();
  const { data: exercises, isLoading } = useQuery<Exercise[]>({ queryKey: ["/api/exercises"] });

  const [search, setSearch] = useState("");
  const [filterMuscle, setFilterMuscle] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [showSpineSafe, setShowSpineSafe] = useState(false);

  // Add exercise dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newCategory, setNewCategory] = useState("compound");
  const [newMuscle, setNewMuscle] = useState("chest");
  const [newEquipment, setNewEquipment] = useState("barbell");
  const [newSpineSafe, setNewSpineSafe] = useState(true);
  const [newNotes, setNewNotes] = useState("");

  const createExercise = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "./api/exercises", {
        name: newName,
        category: newCategory,
        muscleGroup: newMuscle,
        equipment: newEquipment,
        isSpineSafe: newSpineSafe,
        notes: newNotes || null,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exercises"] });
      toast({ title: "Exercise added" });
      setDialogOpen(false);
      setNewName("");
      setNewNotes("");
    },
  });

  const filtered = (exercises ?? []).filter((ex) => {
    if (search && !ex.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterMuscle !== "all" && ex.muscleGroup !== filterMuscle) return false;
    if (filterCategory !== "all" && ex.category !== filterCategory) return false;
    if (showSpineSafe && !ex.isSpineSafe) return false;
    return true;
  });

  const categoryColor: Record<string, string> = {
    compound: "bg-chart-1/10 text-chart-1",
    isolation: "bg-chart-3/10 text-chart-3",
    rehab: "bg-chart-2/10 text-chart-2",
    mobility: "bg-chart-4/10 text-chart-4",
  };

  return (
    <div className="p-6 max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold" data-testid="text-exercises-title">Exercise Library</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-exercise">
              <Plus className="w-4 h-4 mr-2" /> Add Exercise
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Exercise</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label>Name</Label>
                <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="e.g., Incline Press" data-testid="input-new-exercise-name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={newCategory} onValueChange={setNewCategory}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {categories.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Muscle Group</Label>
                  <Select value={newMuscle} onValueChange={setNewMuscle}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {muscleGroups.map((m) => (<SelectItem key={m} value={m}>{m.replace("_", " ")}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Equipment</Label>
                <Select value={newEquipment} onValueChange={setNewEquipment}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {equipmentTypes.map((e) => (<SelectItem key={e} value={e}>{e}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox checked={newSpineSafe} onCheckedChange={(v) => setNewSpineSafe(!!v)} id="spine-safe" />
                <Label htmlFor="spine-safe">Spine-safe</Label>
              </div>
              <div className="space-y-1.5">
                <Label>Notes</Label>
                <Textarea value={newNotes} onChange={(e) => setNewNotes(e.target.value)} placeholder="Form cues, modifications..." />
              </div>
              <Button onClick={() => createExercise.mutate()} disabled={!newName || createExercise.isPending} className="w-full" data-testid="button-save-exercise">
                {createExercise.isPending ? "Adding..." : "Add Exercise"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search exercises..."
              className="pl-9"
              data-testid="input-search-exercises"
            />
          </div>
          <Select value={filterMuscle} onValueChange={setFilterMuscle}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Muscle" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Muscles</SelectItem>
              {muscleGroups.map((m) => (<SelectItem key={m} value={m}>{m.replace("_", " ")}</SelectItem>))}
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {categories.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}
            </SelectContent>
          </Select>
          <Button
            variant={showSpineSafe ? "default" : "secondary"}
            size="sm"
            onClick={() => setShowSpineSafe(!showSpineSafe)}
            data-testid="button-spine-safe-filter"
          >
            <Shield className="w-4 h-4 mr-1" />
            Spine-safe only
          </Button>
        </div>
      </Card>

      {/* Exercise grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((ex) => (
          <Card key={ex.id} className="p-4 space-y-2" data-testid={`card-exercise-${ex.id}`}>
            <div className="flex items-start justify-between">
              <h3 className="text-sm font-semibold">{ex.name}</h3>
              {!ex.isSpineSafe && (
                <AlertTriangle className="w-4 h-4 text-chart-5 shrink-0 mt-0.5" />
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Badge variant="secondary" className={cn("text-xs", categoryColor[ex.category])}>
                {ex.category}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {ex.muscleGroup.replace("_", " ")}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {ex.equipment}
              </Badge>
            </div>
            {ex.notes && (
              <p className="text-xs text-muted-foreground">{ex.notes}</p>
            )}
          </Card>
        ))}
      </div>

      {filtered.length === 0 && !isLoading && (
        <div className="py-10 text-center text-sm text-muted-foreground">
          No exercises match your filters
        </div>
      )}
    </div>
  );
}
