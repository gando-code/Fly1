import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { KpiCard } from "@/components/kpi-card";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { formatDate, painColor, todayISO } from "@/lib/utils";
import { Dumbbell, Flame, HeartPulse, Activity, TrendingUp, AlertTriangle, Plus } from "lucide-react";
import type { Workout, RecoveryLog, BodyMetric, WorkoutSet } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts";

export default function Dashboard() {
  const { data: workouts, isLoading: wLoading } = useQuery<Workout[]>({
    queryKey: ["/api/workouts"],
  });
  const { data: recovery, isLoading: rLoading } = useQuery<RecoveryLog[]>({
    queryKey: ["/api/recovery"],
  });
  const { data: metrics, isLoading: mLoading } = useQuery<BodyMetric[]>({
    queryKey: ["/api/metrics"],
  });

  // Trigger seed on first load
  useQuery({
    queryKey: ["/api/seed"],
    queryFn: async () => {
      const res = await apiRequest("POST", "./api/seed");
      return res.json();
    },
    staleTime: Infinity,
  });

  const isLoading = wLoading || rLoading || mLoading;

  const thisWeekWorkouts = (workouts ?? []).filter((w) => {
    const d = new Date(w.date + "T12:00:00");
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    return d >= weekAgo;
  });

  const totalVolume = thisWeekWorkouts.length;
  const latestRecovery = (recovery ?? [])[0];
  const latestMetric = (metrics ?? [])[0];
  const recentWorkouts = (workouts ?? []).slice(0, 5);

  // Pain trend data (last 14 recovery logs)
  const painChartData = (recovery ?? [])
    .slice(0, 14)
    .reverse()
    .map((r) => ({
      date: formatDate(r.date),
      pain: r.backPainLevel ?? 0,
      soreness: r.soreness ?? 0,
    }));

  // Weekly volume chart — workouts per day last 7 days
  const volumeData = (() => {
    const days: { date: string; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      const label = d.toLocaleDateString("en-US", { weekday: "short" });
      const count = (workouts ?? []).filter((w) => w.date === iso).length;
      days.push({ date: label, count });
    }
    return days;
  })();

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-64 rounded-lg" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-sm text-muted-foreground">{formatDate(todayISO())}</p>
        </div>
        <Link href="/workout">
          <Button data-testid="button-new-workout">
            <Plus className="w-4 h-4 mr-2" />
            Log Workout
          </Button>
        </Link>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="This Week"
          value={totalVolume}
          subtitle={`workout${totalVolume !== 1 ? "s" : ""} completed`}
          icon={<Dumbbell className="w-4 h-4" />}
        />
        <KpiCard
          label="Back Pain"
          value={latestRecovery?.backPainLevel ?? "—"}
          subtitle={latestRecovery ? `${formatDate(latestRecovery.date)}` : "No data"}
          icon={<Activity className="w-4 h-4" />}
        />
        <KpiCard
          label="Recovery"
          value={latestRecovery?.sleepQuality ? `${latestRecovery.sleepQuality}/5` : "—"}
          subtitle={latestRecovery?.sleepHours ? `${latestRecovery.sleepHours}h sleep` : "Log recovery"}
          icon={<HeartPulse className="w-4 h-4" />}
        />
        <KpiCard
          label="Body Weight"
          value={latestMetric?.bodyWeight ? `${latestMetric.bodyWeight} lbs` : "—"}
          subtitle={latestMetric ? formatDate(latestMetric.date) : "No data"}
          icon={<TrendingUp className="w-4 h-4" />}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Weekly activity */}
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Weekly Activity</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={volumeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <RechartsTooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Workouts" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Pain trend */}
        <Card className="p-4">
          <h2 className="text-sm font-semibold mb-3">Pain & Soreness Trend</h2>
          {painChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={painChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <RechartsTooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line type="monotone" dataKey="pain" stroke="hsl(var(--chart-5))" strokeWidth={2} dot={{ r: 3 }} name="Back Pain" />
                <Line type="monotone" dataKey="soreness" stroke="hsl(var(--chart-4))" strokeWidth={2} dot={{ r: 3 }} name="Soreness" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[180px] flex items-center justify-center text-sm text-muted-foreground">
              Log recovery data to see trends
            </div>
          )}
        </Card>
      </div>

      {/* Recent workouts */}
      <Card className="p-4">
        <h2 className="text-sm font-semibold mb-3">Recent Workouts</h2>
        {recentWorkouts.length > 0 ? (
          <div className="space-y-2">
            {recentWorkouts.map((w) => (
              <Link key={w.id} href={`/workout/${w.id}`}>
                <div
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-accent transition-colors cursor-pointer"
                  data-testid={`card-workout-${w.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                      <Dumbbell className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <span className="text-sm font-medium">{w.name}</span>
                      <p className="text-xs text-muted-foreground">{formatDate(w.date)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {w.duration && (
                      <span className="text-xs text-muted-foreground tabular-nums">{w.duration}min</span>
                    )}
                    {(w.postWorkoutPain !== null && w.postWorkoutPain !== undefined && w.postWorkoutPain > 5) && (
                      <Badge variant="destructive" className="text-xs">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        Pain {w.postWorkoutPain}/10
                      </Badge>
                    )}
                    {w.overallRating && (
                      <span className="text-xs text-muted-foreground tabular-nums">
                        {"★".repeat(w.overallRating)}{"☆".repeat(5 - w.overallRating)}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="py-10 text-center">
            <Dumbbell className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-3">No workouts yet</p>
            <Link href="/workout">
              <Button size="sm" data-testid="button-first-workout">
                Log your first workout
              </Button>
            </Link>
          </div>
        )}
      </Card>
    </div>
  );
}
