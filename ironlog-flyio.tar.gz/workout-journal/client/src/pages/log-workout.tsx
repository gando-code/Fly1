import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { todayISO, cn } from "@/lib/utils";
import { Plus, Trash2, Save, AlertTriangle } from "lucide-react";
import type { Exercise, InsertWorkout, InsertWorkoutSet } from "@shared/schema";

interface SetRow {
  tempId: number;
  exerciseId: number;
  setNumber: number;
  reps: number | null;
  weight: number | null;
  rpe: number | null;
  isWarmup: boolean;
  notes: string;
}

export default function LogWorkout() {
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const { data: exercises } = useQuery<Exercise[]>({
    queryKey: ["/api/exercises"],
  });

  const [name, setName] = useState("Push Day");
  const [date, setDate] = useState(todayISO());
  const [duration, setDuration] = useState<number | "">("");
  const [notes, setNotes] = useState("");
  const [prePain, setPrePain] = useState<number[]>([0]);
  const [postPain, setPostPain] = useState<number[]>([0]);
  const [painLocation, setPainLocation] = useState<string[]>([]);
  const [energyLevel, setEnergyLevel] = useState<number[]>([3]);
  const [overallRating, setOverallRating] = useState<number[]>([3]);

  const [sets, setSets] = useState<SetRow[]>([]);
  let nextId = sets.length > 0 ? Math.max(...sets.map((s) => s.tempId)) + 1 : 1;

  const [selectedExercise, setSelectedExercise] = useState<string>("");

  function addSet() {
    if (!selectedExercise) return;
    const exId = Number(selectedExercise);
    const existingSets = sets.filter((s) => s.exerciseId === exId);
    // Copy from last set of same exercise, or use sensible defaults
    const lastSet = existingSets[existingSets.length - 1];
    setSets([
      ...sets,
      {
        tempId: nextId,
        exerciseId: exId,
        setNumber: existingSets.length + 1,
        reps: lastSet?.reps ?? 8,
        weight: lastSet?.weight ?? 135,
        rpe: lastSet?.rpe ?? 7,
        isWarmup: false,
        notes: "",
      },
    ]);
  }

  function updateSet(tempId: number, field: keyof SetRow, value: any) {
    setSets(sets.map((s) => (s.tempId === tempId ? { ...s, [field]: value } : s)));
  }

  function removeSet(tempId: number) {
    setSets(sets.filter((s) => s.tempId !== tempId));
  }

  const createWorkout = useMutation({
    mutationFn: async () => {
      const workoutData: InsertWorkout = {
        date,
        name,
        duration: duration ? Number(duration) : null,
        notes: notes || null,
        preWorkoutPain: prePain[0],
        postWorkoutPain: postPain[0],
        painLocation: painLocation.length > 0 ? JSON.stringify(painLocation) : null,
        energyLevel: energyLevel[0],
        overallRating: overallRating[0],
      };
      const res = await apiRequest("POST", "./api/workouts", workoutData);
      const workout = await res.json();

      // Create all sets
      for (const s of sets) {
        const setData: InsertWorkoutSet = {
          workoutId: workout.id,
          exerciseId: s.exerciseId,
          setNumber: s.setNumber,
          reps: s.reps,
          weight: s.weight,
          rpe: s.rpe,
          isWarmup: s.isWarmup,
          notes: s.notes || null,
        };
        await apiRequest("POST", "./api/sets", setData);
      }
      return workout;
    },
    onSuccess: (workout) => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      toast({ title: "Workout saved", description: `${name} logged successfully.` });
      navigate("/");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save workout.", variant: "destructive" });
    },
  });

  // Group sets by exercise
  const groupedSets: { exerciseId: number; exerciseName: string; isSpineSafe: boolean; sets: SetRow[] }[] = [];
  const seenExercises = new Set<number>();
  for (const s of sets) {
    if (!seenExercises.has(s.exerciseId)) {
      seenExercises.add(s.exerciseId);
      const ex = exercises?.find((e) => e.id === s.exerciseId);
      groupedSets.push({
        exerciseId: s.exerciseId,
        exerciseName: ex?.name ?? "Unknown",
        isSpineSafe: ex?.isSpineSafe ?? true,
        sets: sets.filter((ss) => ss.exerciseId === s.exerciseId),
      });
    }
  }

  const painLocations = ["Lower Back", "Upper Back", "Neck", "Shoulders", "Hips", "Knees"];

  return (
    <div className="p-6 max-w-4xl space-y-6">
      <h1 className="text-xl font-bold" data-testid="text-log-workout-title">Log Workout</h1>

      {/* Session info */}
      <Card className="p-4 space-y-4">
        <h2 className="text-sm font-semibold">Session Details</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="workout-name">Workout Name</Label>
            <Input
              id="workout-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Push Day"
              data-testid="input-workout-name"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="workout-date">Date</Label>
            <Input
              id="workout-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              data-testid="input-workout-date"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="workout-duration">Duration (min)</Label>
            <Input
              id="workout-duration"
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value ? Number(e.target.value) : "")}
              placeholder="60"
              data-testid="input-workout-duration"
            />
          </div>
        </div>

        {/* Energy */}
        <div className="space-y-1.5">
          <Label>Energy Level: {energyLevel[0]}/5</Label>
          <Slider
            value={energyLevel}
            onValueChange={setEnergyLevel}
            min={1}
            max={5}
            step={1}
            className="w-48"
            data-testid="slider-energy"
          />
        </div>
      </Card>

      {/* Exercise sets */}
      <Card className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold">Exercises</h2>
          <div className="flex items-center gap-2">
            <Select value={selectedExercise} onValueChange={setSelectedExercise}>
              <SelectTrigger className="w-52" data-testid="select-exercise">
                <SelectValue placeholder="Pick exercise" />
              </SelectTrigger>
              <SelectContent>
                {(exercises ?? []).map((ex) => (
                  <SelectItem key={ex.id} value={String(ex.id)}>
                    {!ex.isSpineSafe && "⚠ "}{ex.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" onClick={addSet} disabled={!selectedExercise} data-testid="button-add-set">
              <Plus className="w-4 h-4 mr-1" /> Set
            </Button>
          </div>
        </div>

        {groupedSets.length === 0 && (
          <div className="py-8 text-center text-sm text-muted-foreground">
            Select an exercise and add sets to begin
          </div>
        )}

        {groupedSets.map((group) => (
          <div key={group.exerciseId} className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">{group.exerciseName}</span>
              {!group.isSpineSafe && (
                <Badge variant="secondary" className="text-xs">
                  <AlertTriangle className="w-3 h-3 mr-1 text-chart-5" />
                  Spine caution
                </Badge>
              )}
            </div>
            <div className="rounded-lg border border-border overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-2 text-xs font-medium text-muted-foreground w-12">Set</th>
                    <th className="text-left p-2 text-xs font-medium text-muted-foreground">Reps</th>
                    <th className="text-left p-2 text-xs font-medium text-muted-foreground">Weight (lbs)</th>
                    <th className="text-left p-2 text-xs font-medium text-muted-foreground">RPE</th>
                    <th className="text-left p-2 text-xs font-medium text-muted-foreground w-16">Warmup</th>
                    <th className="p-2 w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  {group.sets.map((s, i) => (
                    <tr key={s.tempId} className="border-t border-border">
                      <td className="p-2 tabular-nums text-muted-foreground">{i + 1}</td>
                      <td className="p-2">
                        <Input
                          type="number"
                          value={s.reps ?? ""}
                          onChange={(e) => updateSet(s.tempId, "reps", e.target.value ? Number(e.target.value) : null)}
                          className="h-8 w-20"
                          placeholder="8"
                          data-testid={`input-reps-${s.tempId}`}
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          value={s.weight ?? ""}
                          onChange={(e) => updateSet(s.tempId, "weight", e.target.value ? Number(e.target.value) : null)}
                          className="h-8 w-24"
                          placeholder="135"
                          data-testid={`input-weight-${s.tempId}`}
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          value={s.rpe ?? ""}
                          onChange={(e) => updateSet(s.tempId, "rpe", e.target.value ? Number(e.target.value) : null)}
                          className="h-8 w-16"
                          placeholder="7"
                          min={1}
                          max={10}
                          step={0.5}
                          data-testid={`input-rpe-${s.tempId}`}
                        />
                      </td>
                      <td className="p-2">
                        <Checkbox
                          checked={s.isWarmup}
                          onCheckedChange={(v) => updateSet(s.tempId, "isWarmup", !!v)}
                          data-testid={`checkbox-warmup-${s.tempId}`}
                        />
                      </td>
                      <td className="p-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => removeSet(s.tempId)}
                          className="text-muted-foreground"
                          data-testid={`button-remove-set-${s.tempId}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setSelectedExercise(String(group.exerciseId));
                setTimeout(addSet, 0);
              }}
              className="text-xs"
            >
              <Plus className="w-3 h-3 mr-1" /> Add set
            </Button>
          </div>
        ))}
      </Card>

      {/* Pain tracking */}
      <Card className="p-4 space-y-4">
        <h2 className="text-sm font-semibold">Pain Assessment</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>Pre-workout pain: <span className={cn("font-bold tabular-nums", prePain[0] > 5 ? "text-chart-5" : prePain[0] > 3 ? "text-chart-4" : "text-chart-2")}>{prePain[0]}/10</span></Label>
            <Slider value={prePain} onValueChange={setPrePain} min={0} max={10} step={1} data-testid="slider-pre-pain" />
          </div>
          <div className="space-y-2">
            <Label>Post-workout pain: <span className={cn("font-bold tabular-nums", postPain[0] > 5 ? "text-chart-5" : postPain[0] > 3 ? "text-chart-4" : "text-chart-2")}>{postPain[0]}/10</span></Label>
            <Slider value={postPain} onValueChange={setPostPain} min={0} max={10} step={1} data-testid="slider-post-pain" />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Pain Locations</Label>
          <div className="flex flex-wrap gap-2">
            {painLocations.map((loc) => (
              <Badge
                key={loc}
                variant={painLocation.includes(loc) ? "default" : "secondary"}
                className="cursor-pointer"
                onClick={() =>
                  setPainLocation((prev) =>
                    prev.includes(loc) ? prev.filter((l) => l !== loc) : [...prev, loc]
                  )
                }
                data-testid={`badge-pain-${loc.toLowerCase().replace(/\s/g, "-")}`}
              >
                {loc}
              </Badge>
            ))}
          </div>
        </div>
      </Card>

      {/* Notes & Rating */}
      <Card className="p-4 space-y-4">
        <div className="space-y-1.5">
          <Label>Overall Rating: {overallRating[0]}/5</Label>
          <Slider
            value={overallRating}
            onValueChange={setOverallRating}
            min={1}
            max={5}
            step={1}
            className="w-48"
            data-testid="slider-rating"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="workout-notes">Notes</Label>
          <Textarea
            id="workout-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="How did the session feel? Any modifications?"
            data-testid="textarea-workout-notes"
          />
        </div>
      </Card>

      {/* Save */}
      <Button
        onClick={() => createWorkout.mutate()}
        disabled={createWorkout.isPending || !name}
        className="w-full sm:w-auto"
        data-testid="button-save-workout"
      >
        <Save className="w-4 h-4 mr-2" />
        {createWorkout.isPending ? "Saving..." : "Save Workout"}
      </Button>
    </div>
  );
}
